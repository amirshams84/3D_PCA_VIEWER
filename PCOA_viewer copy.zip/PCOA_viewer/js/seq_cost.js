//#################################################################
	//var protocol = document.getElementById("seq_drop").value;
	//###################################################################
	//###################################################################
	//###################################################################
	function merge_table_with_html(platform, sample_quantity, table_id){
		
		var elem =document.getElementById(table_id).lastChild;
			elem.parentNode.removeChild(elem);
		
		var table_body_code = table_generate(platform, sample_quantity);
		//document.getElementById(table_id).getElementsByTagName('tbody')[0] = table_body_code;
		document.getElementById(table_id).appendChild(table_body_code);

	}
	function table_generate(platform, sample_quantity){
		
		var instanse_name_of_Sequencing_protocol=[
					"PE75-mid",
					"PE75-high",
					"PE150-mid",
					"PE150-high",
					"SE75-high",
					];
		var formula_flag_dictionary={};
			formula_flag_dictionary["Library_prep"]=1;
			formula_flag_dictionary["Sequencing_protocol"]=1;
			formula_flag_dictionary["sample_quantity"]=1;
			formula_flag_dictionary["library_prep_kit"]=1;
			formula_flag_dictionary["library_prep_labor"]=1;
			formula_flag_dictionary["seqencing_kit"]=1;
			formula_flag_dictionary["sequencing_labor"]=1;
			formula_flag_dictionary["data_processing"]=1;
			formula_flag_dictionary["data_analysis"]=1;
			formula_flag_dictionary["total"]=1;
			formula_flag_dictionary["total_per_sample"]=1;
			formula_flag_dictionary["million_reads_per_sample"]=1;
		
		var Library_Prep_dictionary = Library_Prep_get(platform);
		var keys = []
		for(var key in Library_Prep_dictionary) {
			window[key] = Library_Prep_dictionary[key];
		}
		//console.log(Library_Prep_dictionary)
		//var sample_quantity_array = sample_quantity_array_maker(sample_quantity, min_num_samples_kit, max_num_samples_run);
		var tbdy = document.createElement("tbody");
		tbdy.style.fontSize="small";
	 	
		for(var each_protocol_index = 0; each_protocol_index < instanse_name_of_Sequencing_protocol.length; each_protocol_index++){
			var tr = document.createElement("tr");
			//console.log(instanse_name_of_Sequencing_protocol[each_protocol_index]);
			var cells=[];  
			var calcs = [];
			calcs = calculation(
								sample_quantity,
								instanse_name_of_Sequencing_protocol[each_protocol_index],
								each_protocol_index + 1,
								platform,
								formula_flag_dictionary
								);
			
			var calcs_length = calcs.length;
			for (var i=0; i <calcs_length; i++){
				if (isFloat(calcs[i]) ){
					if (i > 2 & i< calcs_length - 1 ){
						cells.push('$' + commafy(calcs[i]));
					}
					else{

						cells.push(commafy(calcs[i]));
					}
				}
				else{
					cells.push(calcs[i]);
				}
			}
			
			for(var j=0;j<cells.length;j++){
				var td=document.createElement("td");
					td.appendChild(document.createTextNode(cells[j]))
					td.style.textAlign = "center";
					tr.appendChild(td);
			}
			tbdy.appendChild(tr);
		};
		//console.log(tbdy);
		return tbdy;
	};
	//###################################################################
	//###################################################################
	//###################################################################
	function calculation(sample, protocol, protocol_index, platform, formula_flag_dictionary){
		var Library_Prep_dictionary = Library_Prep_get(platform);
		var keys = []
		for(var key in Library_Prep_dictionary) {
			window[key] = Library_Prep_dictionary[key];
		}
		///////////////////////
		var Sequencing_protocol_dictionary = Sequencing_protocol_get(protocol);
		var keys = []
		for(var key in Sequencing_protocol_dictionary) {
			window[key] = Sequencing_protocol_dictionary[key];
		}
		///////////////////////
		var hourly_rate_dictionary = hourly_rate_get('lab');
		var lab =hourly_rate_dictionary['lab_hourly_rate']; 
		var hourly_rate_dictionary = hourly_rate_get('bioinformatics');
		var bioinformatics = hourly_rate_dictionary['lab_hourly_rate'];
		///////////////////////
		for (var key in formula_flag_dictionary){
			if (formula_flag_dictionary[key] == 1){
				window[key+'_flag'] = 1;
			}else{
				window[key+'_flag'] = 0;
			}
		}
		if(Library_prep_flag==0){
			Library_prep = 0;
		}
		if(Sequencing_protocol_flag==0){
			Sequencing_protocol = 0;
		}
		if(sample_quantity_flag==0){
			var sample_quantity = 0;
		}else{
			var sample_quantity = sample;
		}
		if (library_prep_kit_flag==1){
			var library_prep_kit = (Math.max(min_num_samples_kit,sample)) * reagent_cost_per_sample;
		}else{
			var library_prep_kit = 0;
		}
		if (library_prep_labor_flag){
			var library_prep_labor = (Math.max(min_num_samples_kit,sample))*library_prep_hours_per_sample *lab;
		}else{
			var library_prep_labor = 0;
		}
		if (seqencing_kit_flag){
			var seqencing_kit = sequencing_kit_price;
		}else{
			var seqencing_kit = 0;
		}
		if (sequencing_labor_flag){
			var sequencing_labor = sequencing_hours_per_run * lab;
		}else{
			var sequencing_labor = 0;
		}
		if (data_processing_flag){
			var data_processing = data_processing_hours_per_run * lab;
		}else{
			var data_processing = 0;
		}
		if (data_analysis_flag){
			var data_analysis = ((Math.max(min_samples_data_analysis,sample)*data_analysis_hours_per_sample * bioinformatics));
		}else{
			var data_analysis = 0;
		}
		if (total_flag){
			var total = library_prep_kit+ library_prep_labor+ seqencing_kit+ sequencing_labor+ data_processing+ data_analysis;
		}else{
			var total = 0;
		}
		if (total_per_sample_flag & sample > 0){
			var total_per_sample = (total / sample);
		}else if (sample<= 0 || total_per_sample_flag==0 ){
			var total_per_sample = 0;
		}
		if (million_reads_per_sample_flag & sample > 0){
			var million_reads_per_sample = (million_reads_per_kit/ sample);
		}else if (sample<= 0 || million_reads_per_sample_flag){
			var million_reads_per_sample = 0;
		}
		var calcs = [];
		calcs = [
				protocol_index,
				protocol,
				sample,
				library_prep_kit,
				library_prep_labor,
				seqencing_kit,
				sequencing_labor,
				data_processing,
				data_analysis,
				set_precision(total),
				set_precision(total_per_sample),
				set_precision(million_reads_per_sample)
				];
		return calcs;    
	}// end of calculate function
	//###################################################################
	//###################################################################
	//###################################################################
	function sample_quantity_array_maker(sample, min_num_samples_kit, max_num_samples_run){
		var cells = [];
		var sample_array = [];

		if(sample > max_num_samples_run){
			sample_array = [0, max_num_samples_run, sample];
		}else if(sample <= 0){
			sample_array = [0,sample];
		}else{
			for (var i = min_num_samples_kit; i <= max_num_samples_run; i += min_num_samples_kit){
			if(sample == i){
				sample_array = [0, sample]
				break;
			}
			else if(sample > i && sample < i + min_num_samples_kit){
				sample_array = [0, i, sample, i + min_num_samples_kit]
				break;
			}
			else if(sample < i){
				sample_array = [0, sample, i];
				break;
			}
			}//end of for loop
		}// end of else
		//console.log(sample_array)
		return sample_array;
	}
	//###################################################################
	//###################################################################
	//###################################################################
	function Sequencing_protocol_get(quest){
		array_of_object_dictionary = [];
		var object_dictionary={}; 
			object_dictionary["sequencing_kit_price"] = 948;
			object_dictionary["sequencing_hours_per_run"] = 8;
			object_dictionary["million_reads_per_kit"] = 160;
			object_dictionary["production"] = 1;
			object_dictionary["Sequencing_protocol"] = "PE75-mid";
			object_dictionary["data_processing_hours_per_run"] = 2;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["sequencing_kit_price"] = 2431;
			object_dictionary["sequencing_hours_per_run"] = 8;
			object_dictionary["million_reads_per_kit"] = 320;
			object_dictionary["production"] = 1;
			object_dictionary["Sequencing_protocol"] = "PE75-high";
			object_dictionary["data_processing_hours_per_run"] = 4;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["sequencing_kit_price"] = 1517;
			object_dictionary["sequencing_hours_per_run"] = 12;
			object_dictionary["million_reads_per_kit"] = 160;
			object_dictionary["production"] = 1;
			object_dictionary["Sequencing_protocol"] = "PE150-mid";
			object_dictionary["data_processing_hours_per_run"] = 4;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["sequencing_kit_price"] = 3890;
			object_dictionary["sequencing_hours_per_run"] = 12;
			object_dictionary["million_reads_per_kit"] = 320;
			object_dictionary["production"] = 1;
			object_dictionary["Sequencing_protocol"] = "PE150-high";
			object_dictionary["data_processing_hours_per_run"] = 4;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["sequencing_kit_price"] = 1264;
			object_dictionary["sequencing_hours_per_run"] = 8;
			object_dictionary["million_reads_per_kit"] = 320;
			object_dictionary["production"] = 1;
			object_dictionary["Sequencing_protocol"] = "SE75-high";
			object_dictionary["data_processing_hours_per_run"] = 2;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary = {};
		var keys  = Object.keys(array_of_object_dictionary);
		for(var i=0;i<keys.length;i++){
			if (quest == array_of_object_dictionary[i]["Sequencing_protocol"]){
				object_dictionary =  array_of_object_dictionary[i];
			}
		}
		return object_dictionary;
	}//end of Sequencing_protocol function
	//###################################################################
	//###################################################################
	//###################################################################
	function Library_Prep_get(quest){
		array_of_object_dictionary = [];
		var object_dictionary={}; 
			object_dictionary["library_prep_hours_per_sample"] = 0.5;
			object_dictionary["max_num_samples_run"] = 24;
			object_dictionary["min_num_samples_labor"] = 6;
			object_dictionary["min_samples_data_analysis"] = 4;
			object_dictionary["reagent_cost_per_sample"] = 48.75;
			object_dictionary["production"] = 1;
			object_dictionary["data_analysis_hours_per_sample"] = 1;
			object_dictionary["library_kit_price"] = 1170;
			object_dictionary["Library_Prep"] = "gDNA-Seq PCR-Free";
			object_dictionary["min_num_samples_kit"] = 6;
			object_dictionary["samples_per_kit"] = 24;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["library_prep_hours_per_sample"] = 0.5;
			object_dictionary["max_num_samples_run"] = 96;
			object_dictionary["min_num_samples_labor"] = 24;
			object_dictionary["min_samples_data_analysis"] = 4;
			object_dictionary["reagent_cost_per_sample"] = 48.75;
			object_dictionary["production"] = 1;
			object_dictionary["data_analysis_hours_per_sample"] = 1;
			object_dictionary["library_kit_price"] = 4680;
			object_dictionary["Library_Prep"] = "gDNA-Seq PCR-Free HT";
			object_dictionary["min_num_samples_kit"] = 48;
			object_dictionary["samples_per_kit"] = 96;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["library_prep_hours_per_sample"] = 0.5;
			object_dictionary["max_num_samples_run"] = 24;
			object_dictionary["min_num_samples_labor"] = 12;
			object_dictionary["min_samples_data_analysis"] = 4;
			object_dictionary["reagent_cost_per_sample"] = 78;
			object_dictionary["production"] = 1;
			object_dictionary["data_analysis_hours_per_sample"] = 1;
			object_dictionary["library_kit_price"] = 3744;
			object_dictionary["Library_Prep"] = "mRNA-Seq Stranded";
			object_dictionary["min_num_samples_kit"] = 12;
			object_dictionary["samples_per_kit"] = 48;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["library_prep_hours_per_sample"] = 1;
			object_dictionary["max_num_samples_run"] = 24;
			object_dictionary["min_num_samples_labor"] = 12;
			object_dictionary["min_samples_data_analysis"] = 4;
			object_dictionary["reagent_cost_per_sample"] = 135.88;
			object_dictionary["production"] = 1;
			object_dictionary["data_analysis_hours_per_sample"] = 1;
			object_dictionary["library_kit_price"] = 6522;
			object_dictionary["Library_Prep"] = "Total RNA-seq (ribo-zero mammal)";
			object_dictionary["min_num_samples_kit"] = 12;
			object_dictionary["samples_per_kit"] = 48;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
			object_dictionary["library_prep_hours_per_sample"] = 1;
			object_dictionary["max_num_samples_run"] = 24;
			object_dictionary["min_num_samples_labor"] = 12;
			object_dictionary["min_samples_data_analysis"] = 4;
			object_dictionary["reagent_cost_per_sample"] = 146.25;
			object_dictionary["production"] = 1;
			object_dictionary["data_analysis_hours_per_sample"] = 1;
			object_dictionary["library_kit_price"] = 7020;
			object_dictionary["Library_Prep"] = "Total RNA stranded (ribo-zero_GOLD mammal)";
			object_dictionary["min_num_samples_kit"] = 12;
			object_dictionary["samples_per_kit"] = 48;
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary = {};
		var keys  = Object.keys(array_of_object_dictionary);
		for(var i=0;i<keys.length;i++){
			if (quest == array_of_object_dictionary[i]["Library_Prep"]){
				object_dictionary =  array_of_object_dictionary[i];
			}
		}

		return object_dictionary;
	}//end of Library_Prep function
	//###################################################################
	//###################################################################
	//###################################################################
	function hourly_rate_get(quest){
		array_of_object_dictionary = [];
		var object_dictionary={}; 
		object_dictionary["lab_hourly_rate"] = 15;
		object_dictionary["production"] = 1;
		object_dictionary["hourly_rate"] = "lab";
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary={}; 
		object_dictionary["lab_hourly_rate"] = 15;
		object_dictionary["production"] = 1;
		object_dictionary["hourly_rate"] = "bioinformatics";
		array_of_object_dictionary.push(object_dictionary);
		var object_dictionary = {};
		var keys  = Object.keys(array_of_object_dictionary);
		for(var i=0;i<keys.length;i++){
			if (quest == array_of_object_dictionary[i]["hourly_rate"]){
				object_dictionary =  array_of_object_dictionary[i];
			}
		}
		return object_dictionary;
	}//end of hourly_rate function
	//###################################################################
	//###################################################################
	//###################################################################
	function set_precision(number){
		return number.toFixed(2);
	}
	//###################################################################
	//###################################################################
	//###################################################################
	function isFloat(val) {
		var floatRegex = /^-?\d+(?:[.,]\d*?)?$/;
		if (!floatRegex.test(val))
		return false;
		val = parseFloat(val);
		if (isNaN(val)){
			return false;
		}
		return true;
	}
	//###################################################################
	//###################################################################
	//###################################################################
	function commafy(input){
		var nStr = input + "";
		nStr = nStr.replace( /\,/g, "");
		x = nStr.split( "." );
		x1 = x[0];
		x2 = x.length > 1 ? "." + x[1] : "";
		var rgx = /(\d+)(\d{3})/;

		while ( rgx.test(x1) ) {
			x1 = x1.replace( rgx, "$1" + "," + "$2" );
		}
		input = x1 + x2;
		return input
	} // end of commafy function
	//###################################################################
	//###################################################################
	//###################################################################
	function ECHO_sample_quantity(){
		
		document.getElementById("sample_quantity").value="100";
		var protocol = document.getElementById("sample_quantity");
		console.log(protocol.value)
	}
	//###################################################################
	//###################################################################
	//###################################################################